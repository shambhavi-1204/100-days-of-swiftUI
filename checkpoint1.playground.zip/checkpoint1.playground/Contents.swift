import Cocoa

// MARK: - CHECKPOINT 1 - SIMPLE DATA TYPES
// Making a simple temperature converter from celsius to farhenheit

let celsius: Double = 32.0
let fahrenheit: Double

fahrenheit = 9/5 * celsius + 32
print("Temperature in celsius: \(celsius)C, Temperature in fahrenheit: \(fahrenheit)F.")
